const SerialPort = require('serialport');


const sensor = (req, res, next) => {
    var readings = [];
    var BPM = [];
    var SPO2 = [];
    var Temp = [];
    var i = 0;
    const port = new SerialPort('COM3', {
        baudRate: 115200,
        parser: new SerialPort.parsers.Readline('\n')
    });


    function tryParseJson(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return JSON.parse(str);
    }

    port.on('open', function () {
        console.log('Opened port...');
        port.on('data', function (data) {
            const sensorData = tryParseJson(data);
            if (sensorData && sensorData.spo != 0) {
                BPM[i] = sensorData.spo - 10;
                SPO2[i] = sensorData.spo;
                Temp[i] = sensorData.temp;
                console.log('BPM :', BPM[i]);
                console.log('SPO2 :', SPO2[i]);
                console.log('Temp :', Temp[i]);
                if (SPO2[i] == SPO2[i - 1]) {
                    readings[0] = BPM[i];
                    readings[1] = SPO2[i];
                    readings[2] = Temp[i];
                    port.close(function () {
                        console.log('Closed Port');
                        console.log(readings);
                        var json = JSON.stringify(readings);
                        BPM = [];
                        SPO2 = [];
                        Temp = [];
                        readings = [];
                        res.json(json);
                    });
                }
                i++;
            }
        });
    });
}


module.exports = {
    sensor
}