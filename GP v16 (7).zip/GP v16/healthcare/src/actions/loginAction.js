

export const loginAction=(dispatch)=>
{

    dispatch({

        type:"loggedIn",
        payload: "omar",

    });
}