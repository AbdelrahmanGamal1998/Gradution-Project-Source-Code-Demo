

export const toggleAction=(dispatch)=>
{

    dispatch({

        type:"clicked",
        

    });
}